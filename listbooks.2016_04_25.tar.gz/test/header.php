<!DOCTYPE html PUBLIC>
<html>
<head>
    <LINK href="/css/styles.css" type=text/css rel=stylesheet>
    <LINK href="/css/modal-add.css" type=text/css rel=stylesheet>
    <LINK href="/css/modal-edit.css" type=text/css rel=stylesheet>
    <LINK href="/css/preloader.css" type=text/css rel=stylesheet>
    
    <script type="text/javascript" src="/js/jquery/jquery.js"></script>
    <link rel="stylesheet" type="text/css" href="/css/jquery/jquery-ui.min.css">
    <script type="text/javascript" src="/js/jquery/jquery-ui.min.js"></script>
    <script type="text/javascript" src="/js/jquery/jquery.easing.min.js"></script>
    <script type="text/javascript" src="/js/jquery/jquery.mousewheel.min.js"></script>
    
    <script type="text/javascript" src="/js/modal-add.js"></script>
    <script type="text/javascript" src="/js/modal-edit.js"></script>
    <script type="text/javascript" src="/js/add-str.js"></script>
    <script type="text/javascript" src="/js/save-str.js"></script>
    <script type="text/javascript" src="/js/delete-str.js"></script>
</head>
