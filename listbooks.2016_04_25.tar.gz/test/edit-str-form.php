<div id='e_modal_form<? echo $lid ?>'>
    <input type=button id="e_modal_close" value=x>
	<form id="e-str-form">
	    <div>
		<div>
		    Название книги*:
		    <br>
		    <input type=hidden id=oldname<? echo $lid ?> value='<? echo $result["Name"]?>'>
		    <input maxlength=150 type=text id=name<? echo $lid ?> name=name value='<? echo $result["Name"]?>' style='width:400px;'>
		    <span id=err_1></span>
		</div>
		<div>
		    Автор*:
		    <br>
		    <input type=hidden id=oldauthor<? echo $lid ?> value='<? echo $result["Author"]?>'>
		    <input maxlength=150 type=text id=author<? echo $lid ?> name=author value='<? echo $result["Author"]?>' style='width:400px;'>
		    <span id=err_2></span>
		</div>
		<div>
		    Цена*:
		    <input type=hidden id=oldprice<? echo $lid ?> value='<? echo $result["Price"]?>'>
		    <br><input maxlength=10 placeholder="500" type=text id=price<? echo $lid ?> name=price value='<? echo $result["Price"]?>' style='width:100px;'> руб
		    <span id=err_3></span>
		</div>
	    </div>	
	    <div>
		<input type=button class="e-save-str" id=<? echo $lid ?> value='OK'>
		<input type=button id="e_modal_reject" value='Отмена'>
	    </div>	
	</form>
</div>
<div id="e_modal_overlay<? echo $lid ?>"></div>
