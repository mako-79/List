$(document).ready(function(){
		
	    $("#add-str").click(function(e){

		var n_name = $("#n_name").val();
		var n_author = $("#n_author").val();
		var n_price = $("#n_price").val();
		var n_id = $("#n_id").val();
		var str = "<tr id='li-"+n_id+"'><td>"+n_id+"</td><td>"+n_name+"</td><td>"+n_author+"</td><td>"+n_price+"</td><td><img width=20 id="+n_id+" class=edit-click src='/images/edit.png'></td><td><input type=checkbox id=did class=checkbox value='"+n_id+"'></td></tr>";
		//var ch_name = /^[a-zA-Zа-яА-Я0-9\-\_\s\.\,\!\?]+$/;
		//var ch_phone = /^[0-9]+$/;
		//var ch_login = /^[0-9]+$/;
		
		var error_1;
		var error_2;
		var error_3;
		
		// Запрещаем стандартное поведение для кнопки submit
		    e.preventDefault();
		    //$("#n_alias").blur(function(){  
	    	
	    	    			
		 //  if( error_1 == 1){
			
        		$.ajax({
        		    type: "POST",  
            		    url: "add-str.php",
            		    data:"n_id="+n_id+"&n_name="+n_name+"&n_author="+n_author+"&n_price="+n_price,
            		    //data:"n_name="+n_name+"&n_author="+n_author+"&n_price="+n_price,
            		    success: function(response){  
            			alert("Успешно добавлен!");
            			$("#List").append(str);
            		    }
            		}).done( function(){  
            		    $('#add_modal_form').animate({opacity: 0, top: '45%'}, 200,  // плaвнo меняем прoзрaчнoсть нa 0 и oднoвременнo двигaем oкнo вверх
	    			function(){ // пoсле aнимaции
	    			    $(this).css('display', 'none'); // делaем ему display: none;
	    			    $('#add_modal_overlay').fadeOut(400); // скрывaем пoдлoжку
	    			});
	    		    nnid = n_id*1+1;
	    		    $("#n_id").attr({"value":nnid});
	    		});
		//}else{
		//    $("#MessPh").html("НЕТ ДОСТУПА!");
		    //return false;
		//}
    	
    	    });  
});	
