$(document).ready(function(){
	$('#del-str-btn').click(function(){
	    
	    var checkValues = $('.checkbox:checked').map(
		function(){
	            return $(this).val();
	    }).get();
	        
	    $.each( checkValues, function( i, val ){
	    //    $("#"+val).remove();
	    //});
	    //                    return  false;
    		$.ajax({
        	    type: "POST",
            	    url: "del-str.php",
            	    data: 'did=' + val,
        	    beforeSend:function(){
            	    $("#page-preloader").css({"display":"block"});
            	    },
            	    success: function(response){  
			//alert("Удаление выполнено");
			$("#page-preloader").css({"display":"none"});	
            	    }  
    		}).done(function(){
    		    for (var i=0; i < did.length; i++){
			if( did[i].checked == true){	
			    $("#li-"+did[i].value).css({"display":"none"});
			}
		    }
    		});
    	    });
    });
});	
