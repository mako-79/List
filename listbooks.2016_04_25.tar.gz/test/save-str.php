<?
    require 'sub/sub.php';        
    
    $lid = $_POST['lid'];
    
    $name = $_POST['name'];
    $author = $_POST['author'];
    $price = $_POST['price'];
    
    $lid = trim($lid);
    $name = trim($name);
    
    $json = file_get_contents("data/list3.json");
    $Larray = json_decode($json,true);

    //$i=0;
    foreach($Larray as $key => $value){
    	if(in_array($lid, $value)){
    	//if($Larray['ID'] == $lid){
    	    $Larray[$key] = array("ID"=>$lid,"Name"=>$name, "Author" => $author , "Price" => $price);
    	}
    }
    
    $list_JSON = json_encode_cyr($Larray);    
    //$Last_text = $list_JSON;
    
    file_put_contents("data/list3.json",$list_JSON);
    unset($list_JSON);  
?>    
