<?
    require 'sub/sub.php';
    $n_name = $_POST['n_name'];
    $n_author = $_POST['n_author'];
    $n_price = $_POST['n_price'];
    $n_id = $_POST['n_id'];
    
    //$ncol = $col + 1;
    $file = file_get_contents('data/list3.json');  // Открыть файл data.json
    $List = json_decode($file,TRUE);        // Декодировать в массив 
                                      
    unset($file);                               // Очистить переменную $file
    $List[] = array("ID" => $n_id,"Name" => $n_name ,"Author" => $n_author , "Price" => $n_price);
    //$list_text = array("Name" => $n_name ,"Author" => $n_author , "Price" => $n_price);
    $list_JSON = json_encode_cyr($List);
    //$list_JSON = json_encode($list_text);
    //$Last_text = $list_JSON;
    //unset($Last[$col-1]);
    //$Last[$col-1] = ",";
    //$Last[$col] = $Last_text;
    //$Last[$col + 1] = "\n]";
    
    //if(!$n_name ){}
    file_put_contents("data/list3.json", $list_JSON);
?>