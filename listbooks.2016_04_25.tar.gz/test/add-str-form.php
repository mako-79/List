<div id="add_modal_form">
    <input type=button id="add_modal_close" value=x>
	<form id="add-str-form">
	    <input type=hidden id=n_id value='<?echo $new_lid?>'>
	    <div>
		<div>
		    Название книги*:
		    <br><input maxlength=150 placeholder="Война и Мир" type=text id=n_name name=n_name style='width:400px;'>
		    <span id=err_1></span>
		</div>
		<div>
		    Автор*:
		    <br><input maxlength=150 placeholder="Лев Толстой" type=text id=n_author name=n_author style='width:400px;'>
		    <span id=err_2></span>
		</div>
		<div>
		    Цена*:
		    <br><input maxlength=10 placeholder="500" type=text id=n_price name=n_price style='width:100px;'> руб
		    <span id=err_2></span>
		</div>
	    </div>	
	    <div>
		<input type=button id="add-str" value='OK'>
		<input type=button id="add_modal_reject" value='Отмена'>
	    </div>	
	</form>
</div>
<div id="add_modal_overlay"></div>