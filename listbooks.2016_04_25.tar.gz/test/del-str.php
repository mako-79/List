<?
    require 'sub/sub.php';        
    $did = $_POST['did'];
    
    $json = file_get_contents("data/list3.json");
    $darray = json_decode($json,true);
    
	foreach($darray as $key => $value){
	//foreach ($ids as $delid){
    	    //parse_id($delid,$darray);
    	    if(in_array($did,$value)){
    		unset($darray[$key]);
    	    }
	}

    $list_JSON = json_encode_cyr($darray);
    //$Last_text = $list_JSON;
    
    file_put_contents("data/list3.json",$list_JSON);
    unset($list_JSON);  
?>