<?php
    $json = file_get_contents("data/list3.json");
    $array = json_decode($json,true);
    $total = count($array);
    //$addtotal = $total+1;
?>
<? include 'header.php'; ?>
	<? global $lid?>
	<? $last_lid?>
	<? $new_lid?>
<body>
<p>Таблица JSON данных</p>
<div class="list">
    <div><input type=button id="add-str-btn" value="Добавить"><input type=button id="del-str-btn" value="Удалить"></div>
    
    <table class="list-block" id="List">
	<tr>
	    <td>ID</td><td>Название книги</td><td>Автор</td><td>Цена (руб.)</td>
	</tr>
    <!--? $end_element = array_pop($array);?-->	
	<?foreach ($array as $result){?>
	<?
	    $lid = $result["ID"];
	    
	if ($result == end($array)){
	    $last_lid = $lid;
	    $new_lid = $last_lid+1;
	}
	
	?>
	<tr id=li-<? echo $lid ?>>    
	    <td><? echo $result["ID"] ?></td>
	    <td><? echo $result["Name"] ?></td>
	    <td><? echo $result["Author"] ?></td>
	    <td><? echo $result["Price"] ?></td>
	    <td>
		<img width=20 class="edit-click" id=<? echo $lid?> src='/images/edit.png'>
		<? include "edit-str-form.php"; ?>
	    </td>
	    <td><input type=checkbox class=checkbox name="did" id="did" value='<? echo $lid?>'></td>
	</tr>	
    <?}?>
    </table>
    
    <? include 'add-str-form.php'; ?>
</div>
<? include 'footer.php'; ?>